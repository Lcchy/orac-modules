Created by u/d0ntreadthis

I decided to upload midi files for some major, natural minor and harmonic minor scales and their chords.
Enjoy!